<?php
namespace App\Http\Controllers\Admin;
use App\Http\Requests\adminRegisterValidation;
use App\User;
use Illuminate\Http\Resources\Json\ResourceCollection;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Log;
use Session;
use App\Admin;
use stdClass;
use Auth;
class RegisterController extends Controller
{
    
    
    protected function index()
    {
       return view('admin.register');
    }

    protected function store(adminRegisterValidation $request)
    {

        Log::info('Admin\RegisterController@store='.print_r($request->all(),true));
         
            $data=Admin::create($request->all());
     
            return response()->json($data,201);
            Session::flash('success_message','admin create successfully');
          



       
        
    }
}